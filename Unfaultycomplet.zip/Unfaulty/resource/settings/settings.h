#ifndef SETTINGS_H_INCLUDE
#define SETTINGS_H_INCLUDE

int InsideOne(int* slctd);
void settingsMenu(SDL_Surface* screen, Background menu, Background menutop, Button* button, Mix_Chunk* SoundButtonHover, Mix_Chunk* SoundButtonClick, Background settingsBackground, Background circle, int inGame, keybinds *kb, int j1, int j2, Text txt);

#endif //MENU_H_INCLUDE
